<?php

namespace App\Http\Controllers;

use Throwable;
use App\Models\Cliente;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ClienteController extends Controller
{
    public function buscar($id)
    {
        try {
            $cliente = Cliente::buscar($id);

            if ($cliente->count() > 0) {
                return response()->json(["status" => "ok", "data" => $cliente]);
            }

            return response()->json(["status" => "error", "mensaje" => "Error! No se encontró el Cliente!"]);
        } catch (Throwable $e) {
            report($e);
            
            return response()->json(["status" => "error", "mensaje" => "Error! No se encontró el Cliente!"]);
        }
    }
    
    public function registrar($request)
    {
        try {
            $cliente = Cliente::registrar($request);

            if ($cliente) {
                return response()->json(["status" => "ok", "data" => "El cliente se agregó correctamente!"]);
            }
        } catch (Throwable $e) {
            report($e);
            
            return response()->json(["status" => "error", "mensaje" => "Error! No se pudo registrar el Cliente!"]);
        }        
    }

    public function editar(Request $request, $id)
    {
        try {
            $cliente = Cliente::editar($request, $id);

            if ($cliente > 0) {
                return response()->json(["status" => "ok", "mensaje" => "El cliente se actualizó correctamente!"]);
            }

            return response()->json(["status" => "error", "mensaje" => "Error! No se encontró al Cliente!"]);
        } catch (Throwable $e) {
            report($e);
            
            return response()->json(["status" => "error", "mensaje" => "Error! No se pudo actualizar el Cliente!"]);
        }        
    }

    public function eliminar($id)
    {
        try {
            $cliente = Cliente::eliminar($id);

            if ($cliente > 0) {
                return response()->json(["status" => "ok", "mensaje" => "El cliente se eliminó correctamente!"]);
            }

            return response()->json(["status" => "error", "mensaje" => "Error! No se encontró al Cliente!"]);
        } catch (Throwable $e) {
            report($e);
            
            return response()->json(["status" => "error", "mensaje" => "Error! No se pudo eliminar el Cliente!"]);
        }        
    }
}
